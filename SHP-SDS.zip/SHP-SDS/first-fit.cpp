#include <iostream>
#include <vector>
#include <fstream>
#include <cstring>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <map> // Necessário para agrupar os padrões do First Fit

using namespace std;

// ========================================================================
// VARIÁVEIS GLOBAIS E ESTRUTURAS
// ========================================================================
int W, s_x, P, MAXTIME;
vector<int> Wp, D_p, item_orig_id;
char instance[256];
char nameTable[256];

  int factor = 15;

struct Pattern {
    vector<int> a;      
    int repetitions;    
    int waste;          
};

// Estrutura temporária para simular bobinas individuais no First Fit
struct Roll {
    vector<int> a;
    int residual;
};

// ========================================================================
// LEITURA DE DADOS
// ========================================================================
void ReadData(char nameTable[]) { 
    char name[200] = "Instances";
    if (name[strlen(name) - 1] != '/') strcat(name, "/");
    strcat(name, nameTable);

    ifstream in(name);
    if (!in) { cerr << "\nERRO FATAL: Arquivo nao encontrado: " << name << endl; exit(1); }
    
    int dummy, instance_id, num_periods, valor_descartado;
    
    in >> dummy; 
    in >> instance_id >> W >> num_periods >> valor_descartado;
    
    s_x = W; 
    in >> P; 
    
    Wp.assign(P, 0); D_p.assign(P, 0); item_orig_id.assign(P, 0);
    for (int i = 0; i < P; ++i) {
        in >> item_orig_id[i] >> Wp[i] >> D_p[i];
    }

        if(Wp[0]<=200)
     factor=15;
     else
     factor=4;
}

// ========================================================================
// HEURÍSTICA FIRST FIT DECREASING (FASE 1) + 2-OPT E AVALIAÇÃO (FASE 2)
// ========================================================================
void RunFirstFit() {
    auto start_time_ff = chrono::steady_clock::now(); // INÍCIO FASE 1
    
    // --- FASE 1: GERAÇÃO GULOSA (FIRST FIT DECREASING) ---
    
    // 1. Ordena os itens do maior para o menor comprimento
    vector<int> ordered_idx(P);
    for (int i = 0; i < P; ++i) ordered_idx[i] = i;
    sort(ordered_idx.begin(), ordered_idx.end(), [&](int a, int b) { return Wp[a] > Wp[b]; });

    vector<Roll> rolls;

    // 2. Processa unidade por unidade de demanda
    for (int idx = 0; idx < P; ++idx) {
        int i = ordered_idx[idx];
        
        for (int d = 0; d < D_p[i]; ++d) {
            bool placed = false;
            
            // Procura a primeira bobina aberta que tenha espaço
            for (auto& roll : rolls) {
                if (roll.residual >= Wp[i]) {
                    roll.a[i]++;
                    roll.residual -= Wp[i];
                    placed = true;
                    break; // FIRST FIT: Para na primeira que couber
                }
            }
            
            // Se não coube em nenhuma, abre uma nova
            if (!placed) {
                Roll new_roll;
                new_roll.a.assign(P, 0);
                new_roll.a[i] = 1;
                new_roll.residual = W - Wp[i];
                rolls.push_back(new_roll);
            }
        }
    }

    // 3. Agrupa as bobinas idênticas para formar os Padrões (Setups)
    map<vector<int>, int> pattern_counts;
    for (const auto& r : rolls) {
        pattern_counts[r.a]++;
    }

    vector<Pattern> solution;
    for (const auto& pair : pattern_counts) {
        Pattern p;
        p.a = pair.first;
        p.repetitions = pair.second;
        
        int used_space = 0;
        for (int i = 0; i < P; ++i) used_space += p.a[i] * Wp[i];
        p.waste = W - used_space;
        
        solution.push_back(p);
    }

    auto end_time_ff = chrono::steady_clock::now(); // FIM FASE 1
    double time_ff = chrono::duration<double>(end_time_ff - start_time_ff).count();

    int N = solution.size();
    int total_rolls = rolls.size(); // Total de bobinas cortadas


    // --- FASE 2: SEQUENCIAMENTO COM 2-OPT (INCLUINDO DEPOSITO) ---
    auto start_time_2opt = chrono::steady_clock::now(); // INÍCIO FASE 2
    
    int total_setup_cost = 0;
    vector<int> best_path;

    if (N > 0) {
        vector<vector<int>> s_kj(N + 1, vector<int>(N + 1, 0));
        
        for (int j = 0; j < N; ++j) {
            int setup_completo = 0;
            for (int i = 0; i < P; ++i) setup_completo += solution[j].a[i];
            
            s_kj[N][j] = setup_completo; 
            s_kj[j][N] = setup_completo; 

            for (int l = 0; l < N; ++l) {
                if (j == l) continue;
                int a_dif = 0;
                for (int i = 0; i < P; i++) {
                    a_dif += abs(solution[j].a[i] - solution[l].a[i]);
                }
                s_kj[j][l] = a_dif;
            }
        }

        vector<int> cycle(N + 1);
        for (int i = 0; i <= N; ++i) cycle[i] = i;

        bool improved = true;
        while (improved) {
            improved = false;
            for (int i = 0; i < N; i++) {
                for (int j = i + 1; j <= N; j++) {
                    if (i == 0 && j == N) continue; // Evita loop infinito

                    int node1_prev = (i == 0) ? cycle.back() : cycle[i - 1];
                    int node1 = cycle[i];
                    int node2 = cycle[j];
                    int node2_next = (j == N) ? cycle.front() : cycle[j + 1];
                    
                    int current_cost = s_kj[node1_prev][node1] + s_kj[node2][node2_next];
                    int new_cost = s_kj[node1_prev][node2] + s_kj[node1][node2_next];
                    
                    if (new_cost < current_cost) {
                        reverse(cycle.begin() + i, cycle.begin() + j + 1);
                        improved = true;
                    }
                }
            }
        }

        int dummy_idx = -1;
        for (int i = 0; i <= N; ++i) {
            if (cycle[i] == N) { dummy_idx = i; break; }
        }
        for (int i = 1; i <= N; ++i) {
            best_path.push_back(cycle[(dummy_idx + i) % (N + 1)]);
        }

        int current_node = N; 
        for (int i = 0; i < N; ++i) {
            int next_node = best_path[i];
            total_setup_cost += s_kj[current_node][next_node];
            current_node = next_node;
        }
        total_setup_cost += s_kj[current_node][N]; 
    }

    auto end_time_2opt = chrono::steady_clock::now(); // FIM FASE 2
    double time_2opt = chrono::duration<double>(end_time_2opt - start_time_2opt).count();


    // --- CÁLCULO DE CAPACIDADE E FO ---
    double total_material_needed = 0;
    for (int i = 0; i < P; ++i) total_material_needed += (double)D_p[i] * Wp[i];
    const int O = ceil(1.8 * total_material_needed / (double)W);
    
  
    int time_obj = 1;
    int time_item = 2;
    
    int capacity_limit = O + factor * P;
    int capacity_used = (time_obj * total_rolls) + (time_item * total_setup_cost);
    bool is_violated = capacity_used > capacity_limit;

    double obj_value = (double)W * total_rolls + 1.0 * N + (0.1 * W) * total_setup_cost;
    
    double penalty_val = 0.0;
    if (is_violated) {
        penalty_val = ((double)W * 0.1 * W * P) + capacity_used;
        obj_value += penalty_val;
    }

    // --- IMPRESSÃO DOS RESULTADOS ---
    cout << "\n================================================" << endl;
    cout << " RESULTADOS FIRST FIT: " << instance << endl;
    cout << "================================================" << endl;
    
    cout << "[ SEQUENCIA DOS PADROES E SETUPS ]" << endl;
    if (N > 0) {
        int first_id = best_path[0];
        int setup_in = 0;
        for (int i = 0; i < P; ++i) setup_in += solution[first_id].a[i];
        
        cout << " [ DEPOSITO ] --- (Setup Inicial: " << setup_in << " facas) --->" << endl;

        for (int i = 0; i < N; ++i) {
            int id = best_path[i];
            
            cout << " P" << id + 1 << " (Corta " << solution[id].repetitions << "x) | Itens: [ ";
            for (int k = 0; k < P; ++k) {
                if (solution[id].a[k] > 0) {
                    cout << "ID" << item_orig_id[k] << ":" << solution[id].a[k] << " ";
                }
            }
            cout << "]";

            if (i < N - 1) {
                int dist = 0;
                for(int k=0; k<P; k++) dist += abs(solution[id].a[k] - solution[best_path[i+1]].a[k]);
                cout << "\n      | \n      +--- (Muda: " << dist << " facas) --->\n      | \n";
            } else {
                int setup_out = 0;
                for (int k = 0; k < P; ++k) setup_out += solution[id].a[k];
                cout << "\n      | \n      +--- (Retira: " << setup_out << " facas) ---> [ DEPOSITO ]\n";
            }
        }
    }

    cout << "\n[ TEMPO COMPUTACIONAL ]" << endl;
    cout << "Fase 1 (First Fit):   " << fixed << time_ff << " s" << endl;
    cout << "Fase 2 (2-Opt):       " << fixed << time_2opt << " s" << endl;

    cout << "\n[ CAPACIDADE E RESTRICOES ]" << endl;
    cout << "Limite Teorico (O): " << O << endl;
    cout << "Limite Final (O+15P): " << capacity_limit << endl;
    cout << "Capacidade Usada:     " << capacity_used << " (Tempo Objeto: " << total_rolls << ", Tempo Setups: " << total_setup_cost * 2 << ")" << endl;
    
    if (is_violated) {
        cout << "Violou Capacidade?    SIM !!! (Penalidade aplicada: " << fixed << penalty_val << ")" << endl;
    } else {
        cout << "Violou Capacidade?    NAO" << endl;
    }

    cout << "\n[ FUNCAO OBJETIVO FINAL ]" << endl;
    cout << "Total de Objetos: " << total_rolls << " (Peso FO: " << W * total_rolls << ")" << endl;
    cout << "Total de Padroes (N): " << N << " (Peso FO: " << N << ")" << endl;
    cout << "Movimentacao Facas: " << total_setup_cost << " (Peso FO: " << (0.1 * W) * total_setup_cost << ")" << endl;
    if (is_violated) cout << "Penalidade (Violacao): " << fixed << penalty_val << endl;
    cout << "------------------------------------------------" << endl;
    cout << "F.O. FINAL:       " << fixed << obj_value << endl;
    cout << "================================================\n" << endl;

    // --- SALVANDO NO ARQUIVO FF-SDS.csv ---
    // Criei um arquivo separado para não misturar os resultados com os do SHP
    ofstream csv_file("FF-SDS.csv", ios::app);
    if (csv_file.is_open()) {
        csv_file.seekp(0, ios::end);
        if (csv_file.tellp() == 0) {
            csv_file << "Instancia,Objetos,Padroes,SetupCost,CapacidadeUsada,LimiteCapacidade,Violou,Penalidade,FO_Final,Time_FF(s),Time_2Opt(s)\n";
        }
        
        csv_file << instance << "," 
                 << total_rolls << "," 
                 << N << "," 
                 << total_setup_cost << "," 
                 << capacity_used << "," 
                 << capacity_limit << "," 
                 << (is_violated ? 1 : 0) << "," 
                 << fixed << penalty_val << "," 
                 << fixed << obj_value << ","
                 << fixed << time_ff << ","      
                 << fixed << time_2opt << "\n";   
                 
        csv_file.close();
    } else {
        cerr << "\nERRO: Nao foi possivel abrir o arquivo FF-SDS.csv para escrita!" << endl;
    }
}

// ========================================================================
// MAIN 
// ========================================================================
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("\nERRO: Faltou o .csv\n"); exit(1); }
    char nameScenario[256]; strncpy(nameScenario, argv[1], 255); nameScenario[255] = '\0';  
    FILE *arqProblems = fopen(nameScenario, "r"); 
    if (arqProblems == NULL){ printf("\nERRO FATAL!\n"); exit(1); }
    if (fgets(nameTable, sizeof(nameTable), arqProblems) == NULL) exit(1);
    nameTable[strcspn(nameTable, "\n")] = '\0';

    while (fscanf(arqProblems, "%s %d", nameTable, &MAXTIME) == 2) {
        strcpy(instance, nameTable); 
        ReadData(nameTable);
        RunFirstFit(); // Chama o First Fit
        while (fgetc(arqProblems) != '\n' && !feof(arqProblems)); 
    }
    fclose(arqProblems);
    return 0;
}