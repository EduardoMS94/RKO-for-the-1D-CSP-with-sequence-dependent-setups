#include <sys/time.h>
#include <math.h>
#include <cstring>
#include <ctime>
#include <iostream>
#if defined(_WIN32) || defined(_WIN64)  // Windows
    #include <windows.h>
#else  // Unix-like (Linux, macOS)
    #include <time.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <algorithm>
#include <utility>  
#include <numeric>  
#include <map>
#include <limits>
#include <random>
#include <chrono>
#include <iomanip> 
#include <sstream> 
#include <fstream> 
#include <omp.h>
#include <atomic>
#include <gurobi_c++.h>
#include <set>
#include <sys/stat.h>
#include <sys/types.h>

using namespace std;


//Problem specific data
static int Instance_number = 20,
cont = 0,
cont_p = 0, cont_j = 0,
i, t, tt,
T,                                                //size of the planning horizon
P,                                                // number of items
W = 1000,  //object size
Kt, ip = 0, MAXTIME=0;
double aux0 = 0;

int s_c = 0, s_x = 0;   //setup cost e object cost
double time_obj=1, time_item=2;

int feasibleCount = 0;
char instance[100];                         // name of instance
char nameTable[256];                         // name of the instance

vector <int> Wp;
vector<int> D_p;
vector<int> CTt;
vector<double> Stock_costs;


void ReadData(char nameTable[]) { 
       char name[200] = "Instances";

    // Check if the base path ends with a slash.
    // In this case, it doesn't, so we'll add one.
    if (name[strlen(name) - 1] != '/') {
        strcat(name, "/");
    }

    // Now, concatenate the rest of the path.
    strcat(name, nameTable);

    ifstream in(name);
    if (!in) {
        cerr << "No such file: " << name << endl;
        exit(1);
    }
    int dummy;
    in >> dummy; // número de instâncias, pode ser ignorado

    int instance_id, num_periods, MAXTIME;
    in >> instance_id >> W >> num_periods >> MAXTIME;

	cout<< "barra "<< W<<endl;


	s_c = 100; s_x = W; 
    in >> P; // número de tipos (linhas seguintes)
	cout<< "itens "<< P<<endl;

    Wp.clear();
    D_p.clear();
	Wp.resize(P,0);
	D_p.resize(P,0);

    for (int passop= P-1; passop>= 0; --passop) {
        int period;
        int wp_value, dp_value;
        in >> period >> wp_value >> dp_value;
		cout<< "tamanho "<< wp_value<< " demanda "<< dp_value<<endl;

        Wp[passop]=wp_value;
        D_p[passop]=dp_value;
    }



}


void WriteResults(double LP, double IP, double timeBest, double GAP, char instance[], int XJ_values, int YJ_value, int SDSs)
{
    char name[256] = "../Results/results-CGED.csv";

    // Criar o diretório se não existir
#ifdef _WIN32
    _mkdir("../Results");
#else
    mkdir("../Results", 0777);
#endif

    // Verifica se o diretório foi criado corretamente
   // printf("Tentando abrir o arquivo: %s\n", name);

    FILE *arq = fopen(name, "a");  // Modo append ("a") cria se não existir
    if (!arq)
    {
        perror("Erro ao abrir o arquivo"); // Mostra erro do sistema
        exit(1);
    }

   // printf("Arquivo aberto com sucesso! Escrevendo os dados...\n");

    fprintf(arq, "\n%s", instance);
    fprintf(arq, "\t%.3f", LP);
    fprintf(arq, "\t%.3f", IP);
    fprintf(arq, "\t%.3f", GAP);
    fprintf(arq, "\t%.3f", timeBest);

 
        fprintf(arq, "\t%d", XJ_values);
    

    fprintf(arq, "\t%d", YJ_value);
    fprintf(arq, "\t%d", SDSs);

    fclose(arq);
    //printf("Arquivo salvo com sucesso!\n");
}

// Solve subproblem for column generation (Knapsack problem)
double solveKnapsack(const double phi,const vector<double>& duals, const vector<int>& Wp, int W, vector<int>& newPattern) {
    try {
        int numItems = P;
        GRBEnv env = GRBEnv(true);
        env.set("OutputFlag", "0");
        env.start();

        GRBModel model = GRBModel(env);
        vector<GRBVar> vars(numItems);

        // Add decision variables
        for (int i = 0; i < P; ++i) {
            vars[i] = model.addVar(0, GRB_INFINITY, 0, GRB_INTEGER);
        }

        // Add the rod length constraint
        GRBLinExpr lengthConstraint = 0;
        for (int i = 0; i < P; ++i) {
            lengthConstraint += vars[i] * Wp[i];
        }
        model.addConstr(lengthConstraint <= W, "RodLengthConstraint");
        int BigM1=0;
        for(int ii=0;ii<P;ii++)
            BigM1+=D_p[ii];
        
           if (P > 0) 
            BigM1 = int(BigM1 / P);
           else 
            BigM1 = 1;  // Assign a reasonable default value
    
        // Set objective function: Minimize s_x- phi - ∑ dual_i * x_i
        GRBLinExpr obj = s_x - phi;
        for (int i = 0; i < P; ++i) {
            obj -= duals[i] * vars[i];
          //  cout<< duals[i]<< " dual "<<endl;
        }
        model.setObjective(obj, GRB_MINIMIZE);
        model.write("knapsack_model.lp");  // Salva o modelo do subproblema em um arquivo

        model.optimize();

        double reducedCost = GRB_INFINITY;
        if (model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
            reducedCost = model.get(GRB_DoubleAttr_ObjVal);
            newPattern.resize(P, 0);
            for (int i = 0; i < P; ++i) {
                newPattern[i] = static_cast<int>(std::round(vars[i].get(GRB_DoubleAttr_X)));
            }
        }

        // Debug: Print the reduced cost and the generated pattern
      //  std::cout << "Reduced Cost: " << reducedCost << "\nGenerated Pattern: ";
      //  for (int value : newPattern) {
         //   cout << value << " ";
        //}
       // cout << "\n";

        return reducedCost;

    } catch (GRBException& e) {
        cerr << "Error in solveKnapsack: " << e.getMessage() << "\n";
        return GRB_INFINITY;
    } catch (...) {
        cerr << "Exception during solveKnapsack.\n";
        return GRB_INFINITY;
    }
}






int main(int argc, char *argv[]) {
// read scenario name file 



 char nameScenario[256];

 strncpy(nameScenario,argv[1],255);

 nameScenario[255] = '\0';  // string end

// file with test instances and input data
 FILE *arqProblems; 
 arqProblems = fopen (nameScenario, "r"); 

 if (arqProblems == NULL){
     printf("\nERROR: File %s not found\n", nameScenario);
     exit(1);
 }


 // read first line of testScenario file
 if (fgets(nameTable, sizeof(nameTable), arqProblems) == NULL) {
 printf("\nERROR: File %s not found\n", nameTable);
 exit(1);
  }


// Remover o caractere de nova linha "\n"
nameTable[strcspn(nameTable, "\n")] = '\0';


//rewind(arqProblems);  // Reset file pointer (just in case)

char testNameTable[100];
int testMAXTIME;
    while (fscanf(arqProblems, "%s %d", nameTable, &MAXTIME) == 2) {
            
        strcpy(instance, nameTable);
        ReadData(nameTable);
         int XJ=0;
        
        // Limpa o buffer de entrada para a próxima leitura do loop
        while (fgetc(arqProblems) != '\n' && !feof(arqProblems));

        try {

         
            GRBEnv env = GRBEnv(true);
            env.set(GRB_IntParam_OutputFlag, 1); // 1 para ver o log do Gurobi
            env.start();

            GRBModel model = GRBModel(env);
            model.set(GRB_StringAttr_ModelName, instance);
            model.set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);

   // ========================================================================
            // 1. GERAÇÃO DE PADRÕES (Utilizando o algoritmo de DP correto)
            // ========================================================================
            vector<vector<int>> patterns;
          /*  {
                vector<set<vector<int>>> dp(W + 1);
                int numItems = P;

                // Inicializar DP com o padrão vazio
                dp[0].insert(vector<int>(numItems, 0)); 
                
                // Preencher a tabela de DP
                for (int i = 0; i < numItems; i++) {  // Para cada tipo de item
                    for (int w = 0; w <= W; w++) {  // Para cada capacidade possível
                        if (!dp[w].empty()) {  // Se existe um padrão com peso w
                            // Itera sobre uma cópia para evitar problemas com modificação do set
                            set<vector<int>> currentPatterns = dp[w]; 
                            for (auto pattern : currentPatterns) {
                                // Tenta adicionar k=1, 2, 3... cópias do item i
                                int k = 1;
                                while (w + k * Wp[i] <= W) {
                                    vector<int> newPattern = pattern;
                                    newPattern[i] += k;
                                    dp[w + k * Wp[i]].insert(newPattern);
                                    k++;
                                }
                            }
                        }
                    }
                }

                // Transferir todos os padrões únicos e não-vazios para o vetor final
                for (int w = 1; w <= W; w++) {
                    if (!dp[w].empty()) {
                        for (const auto& pattern : dp[w]) {
                            patterns.push_back(pattern);
                        }
                    }
                }
            }*/


               //if CG is required, start RMP with homogeneous cutting patterns
                 for (int i = 0; i < P; i++) {  // Para cada item
                    int imax_fit= floor(W/Wp[i]);
                        for (int iii = 1; iii <= imax_fit; iii++) {  // Para cada item
                                vector<int> aux_pattern(P,0);
                                aux_pattern[i]=iii;
                               patterns.push_back(aux_pattern); 
                               }
                    }
            cout << "\nInstância: " << instance << " | Padrões enumerados: " << patterns.size() << endl;

              // 2. DEFINIÇÃO DE VARIÁVEIS E PARÂMETROS
            int N = patterns.size();
            const int depot_idx = 0; 
             double BIG_M_MTZ = N + 1;

            // --- FASE 1: Todas as variáveis são definidas como CONTÍNUAS ---
            
            // Z_j: Frequência de uso do padrão j
            vector<GRBVar> Z_vars(N);
            for (int j = 0; j < N; j++) {
                Z_vars[j] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "Z_" + to_string(j));
            }

            // U_j: Variável binária que indica se o padrão j é usado
            vector<GRBVar> U_vars(N);
            for (int j = 0; j < N; j++) {
                U_vars[j] = model.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS, "U_" + to_string(j));
            }
            
            // W_jl: Variável binária que indica a transição do padrão j para l
            vector<vector<GRBVar>> W_vars(N + 1, vector<GRBVar>(N + 1));
            for (int j = 0; j <= N; j++) {
                for (int l = 0; l <= N; l++) {
                    if (j != l) {
                        W_vars[j][l] = model.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS, "W_" + to_string(j) + "_" + to_string(l));
                    }
                }
            }

            vector<int> scont_j(patterns.size(),0);
                 for(int j=0;j<patterns.size();j++){
                        for(int i=0; i<P;i++){
                           scont_j[j]+=patterns[j][i];
                                }
                        }
                       
            // V_j: Variável de posição para eliminação de sub-tour (MTZ)
            vector<GRBVar> V_vars(N + 1);
            for (int j = 0; j <= N; j++) {
                V_vars[j] = model.addVar(0.0, N, 0.0, GRB_CONTINUOUS, "V_" + to_string(j));
            }
            // Ancorando a posição do depósito em 0 para garantir uma única sequência
            V_vars[depot_idx].set(GRB_DoubleAttr_UB, 0.0);

            

            vector<vector<int>> s_kj(patterns.size(), vector<int>(patterns.size(), 0));

            // 3. FUNÇÃO OBJETIVO
            GRBLinExpr obj = 0;
            for (int j = 0; j < N; j++) {
                obj += s_x * Z_vars[j]; // Custo do material
                 obj +=  U_vars[j];   // custo padrão de corte
                for (int l = 0; l < N; l++) {
                    if (j != l) {
                        // Custo de setup (simulado, substitua pela sua lógica real)
                        int aij=0, ail=0, a_dif=0;
                                                for(int i=0; i<P;i++){
                                                    a_dif+=abs(patterns[j][i]-patterns[l][i]);
                                                      aij+=patterns[j][i];
                                                      ail+=patterns[l][i];
                                                }
                                               // s_kj[j][l]=abs(aij- ail);
                                               s_kj[j][l]=a_dif;
                                              //  a_dif=(a_dif-s_kj[j][l])/2; // contador de reposicionamento de facas
                       // double setup_cost = s_c *  (s_kj[j][l]+a_dif/3); // setup dependente de remoção/inserção e reposicionamento de facas
                       // double setup_cost = s_c *  (s_kj[j][l]); // setup dependente de remoção/inserção de facas
                       // obj += setup_cost * W_vars[j][l];
                       obj += s_c*s_kj[j][l]* W_vars[j+1][l+1];

                    }
                }
            }

                            for (int l = 1; l <= N; l++) {
                        // Custo de setup inicial e final
                        int ail=0;
                                                for(int i=0; i<P;i++){
                                                      ail+=patterns[l-1][i];
                                                }
                                             
                        double setup_cost = s_c * ail;
                        obj += setup_cost * W_vars[depot_idx][l]; //setup inicial
                        obj += setup_cost * W_vars[l][depot_idx];  //setup final
                    
                }
            model.setObjective(obj, GRB_MINIMIZE);
            
            // 4. RESTRIÇÕES

            
            
            // a) Demanda
            vector<GRBConstr> demandConstraints(P);
            for (int i = 0; i < P; ++i) {
                GRBLinExpr demandExpr = 0;
                for (int j = 0; j < N; ++j) {
                    demandExpr += patterns[j][i] * Z_vars[j];
                }
                demandConstraints[i]=model.addConstr(demandExpr == D_p[i], "Demand_" + to_string(i));
            }

           

            // b) Vínculo Z_j -> U_j
            int M_freq = 0; 
            
            for(int ii=0;ii<P;ii++)
                     M_freq+=D_p[ii];


            for (int j = 0; j < N; j++) {
                model.addConstr(Z_vars[j] <= M_freq * U_vars[j], "Link_ZU_" + to_string(j));
            }
  cout<< " err "<<endl;
            // c) Fluxo para Padrões Reais (j = 0..N-1)

              vector<GRBConstr> Flow_in(N);
                vector<GRBConstr> Flow_out(N);
            for (int j = 0; j < N; j++) {
                GRBLinExpr in_degree = 0, out_degree = 0;
                for (int l = 0; l <= N; l++) {
                    if (l != (j+1)) {
                        in_degree += W_vars[l][j+1];
                        out_degree += W_vars[j+1][l];
                    }
                }
               Flow_in[j]= model.addConstr(in_degree == U_vars[j], "In_Flow_" + to_string(j));
              Flow_out[j]=  model.addConstr(out_degree == U_vars[j], "Out_Flow_" + to_string(j));
            }

                GRBConstr Flow_start;
                GRBConstr Flow_end;    
                
             

            // d) Fluxo para o Depósito (j=N)
            GRBLinExpr start_tour = 0;
            for (int j = 0; j < N; j++) start_tour += W_vars[depot_idx][j+1];
            Flow_start=model.addConstr(start_tour <= 1, "Start_Tour");

            GRBLinExpr end_tour = 0;
            for (int j = 0; j < N; j++) end_tour += W_vars[j+1][depot_idx];
           Flow_end= model.addConstr(start_tour == end_tour, "Connect_Tour");

          

           // e) Eliminação de Sub-tour (MTZ)
            vector<vector<GRBConstr>> MTZ(N, vector<GRBConstr>(N));
            for (int j = 0; j < N; j++) {
                for (int l = 0; l < N; l++) {
                    if (j != l) {
                       MTZ[j][l]= model.addConstr(V_vars[l+1] >= V_vars[j+1] + 1 - BIG_M_MTZ * (1 - W_vars[j+1][l+1]), "MTZ_" + to_string(j) + "_" + to_string(l));
                    }
                }
            }

               cout<< " err 0000 "<<endl;
                // g) Restrição de Ativação Mínima (para evitar "nós de passagem")
              for (int j = 0; j < N; ++j) {
                   model.addConstr(Z_vars[j] >= U_vars[j], "Min_Activation_" + to_string(j));
                 }
   // Cálculo do número de objetos |O| conforme a fórmula
        double total_material_needed = 0.0;
              int M = 0; 
               
            for(int ii=0;ii<P;ii++)
                     M+=D_p[ii];

        for (int i = 0; i < P; ++i) {
            total_material_needed += (double)D_p[i] * Wp[i];
            
        }
        const int O = ceil(1.8 * total_material_needed / W);
        //const int O = ceil(1.2 * M);

            // Restrição de Capacidade
            GRBConstr Capacity;
            GRBLinExpr capacityExpr = 0;
            for (int j = 0; j < N; ++j) {
                capacityExpr += time_obj * Z_vars[j];
                for (int l = 0; l < N; ++l) {
                     if (j != l) {
                        capacityExpr += W_vars[j+1][l+1] * time_item * s_kj[j][l];
                     }
                }
            }
            Capacity = model.addConstr(capacityExpr <= 4*P+O, "capacity_" + to_string(0));

            model.update();
            model.write("master_model_sequencing.lp");


           

            // ========================================================================
            // FASE 1: OTIMIZAÇÃO DA RELAXAÇÃO LINEAR
            // ========================================================================
            cout << "\n--- FASE 1: Resolvendo a Relaxação Linear ---" << endl;
            model.optimize();
            
            double lowerBound = 0.0;
            if (model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
                lowerBound = model.get(GRB_DoubleAttr_ObjVal);
                cout << "Valor da Relaxação Linear (Limitante Inferior): " << fixed << setprecision(4) << lowerBound << endl;
            } else {
                cout << "Relaxação Linear não encontrou solução ótima. Status: " << model.get(GRB_IntAttr_Status) << endl;
                continue; 
            }
            double LP_value=lowerBound;

            // ========================================================================
            // Column generation procedure
            // ========================================================================

  // Column generation loop
                int tailingOffLimit = 5;
                 int consecutiveNoImprovement = 0;
                  double previousReducedCost = GRB_INFINITY;
                  bool Check_CG=0;
                  int it_RMP=0;																				//iterations without improvements in the objective function value
  //of restricted master problem in the column generation procedure

                 double ZRMPit1=10000000000000000, ZRMPit2=LP_value;	
                  auto start = std::chrono::high_resolution_clock::now();
                  int number_CG=0;

while (true) {


  //   masterModel.optimize();
   //  ZRMPit2= masterModel.get(GRB_DoubleAttr_ObjVal);
    std::cout << "Enters CG " <<std::endl;

    Check_CG=0;
      // Get dual values from the RMP
      vector<double> duals(P, 0.0); //inicializa vetor de duais com valores 0.0
      double cduals=0.0;// dual da capacidade
        cduals = Capacity.get(GRB_DoubleAttr_Pi); //recupera o dual da restrição no modelo após otimização

       for (int i = 0; i < P; ++i) {
        duals[i] = demandConstraints[i].get(GRB_DoubleAttr_Pi); // recupera dual das demandas
        }
         
      // Solve the subproblem to generate new patterns
      std::vector<int> newPattern(P, 0);
      double reducedCost = solveKnapsack(cduals,duals, Wp, W, newPattern);
       number_CG++;
   if(reducedCost<-0.0001){
      
          //se custo reduzido é negativo, coluna gerada é valida
          Check_CG=1;
       
        // Add the new pattern to the RMP
          patterns.push_back(newPattern);
  
   //cout << "Removendo " << N * (N - 1) << " restrições MTZ antigas..." << endl;
    for (int j = 0; j < N; j++) {
      for (int l = 0; l < N; l++) {
        if (j != l) {
            // Remove a restrição do modelo Gurobi usando o objeto armazenado
            model.remove(MTZ[j][l]);
         }
        }
      }           

            N = patterns.size();
            BIG_M_MTZ = N + 1;
          // add the generated pattern to modelo masterModel
    
           GRBVar newVar = model.addVar(0, GRB_INFINITY, s_x, GRB_CONTINUOUS, "x" + std::to_string(patterns.size() - 1));
     
            Z_vars.push_back(newVar);

           GRBVar newYVar = model.addVar(0, 1, 1, GRB_CONTINUOUS, "y" + std::to_string(patterns.size() - 1));

              U_vars.push_back(newYVar);

              GRBVar NewZVar = model.addVar(0.0, N, 0.0, GRB_CONTINUOUS, "V_" + to_string(patterns.size()));
              V_vars.push_back(NewZVar);
          
                int newIndex = patterns.size() - 1; // para o vetor patterns newIndex+1 para variavel W


            model.addConstr(newVar  >= newYVar, "Min_Activation_" + to_string(newIndex)); //evita setup sem frequencia

        // restrição de setup
          GRBLinExpr setupExpr = 0;
           setupExpr += M_freq * newYVar;
           GRBConstr newYsetup = model.addConstr(setupExpr >= newVar, "Link_ZU_" + to_string(newIndex));           

                      // update vector of changeover numbers
                    for (auto& row : s_kj) {
                           row.push_back(0);
                        }
                       s_kj.push_back(vector<int>(patterns.size(), 0));

                         for (int jj = 0; jj < patterns.size()-1; jj++) {
                                                   int a_diff=0;
                                                for(int i=0; i<P;i++){
                                                    a_diff+=abs(newPattern[i]-patterns[jj][i]);
                                                }

                                s_kj[newIndex][jj] = a_diff;
                                s_kj[jj][newIndex] = a_diff;
                         }
                         
  // Adiciona uma nova coluna às linhas existentes
            W_vars.resize(N + 1);
                for (auto& row : W_vars) {
                       row.resize(N + 1);
                      }

                    int pattern_i_count=0;
                                            for(int i=0; i<P;i++){
                                                    pattern_i_count+=abs(newPattern[i]);
                                                }

                  for (int k = 0; k < patterns.size()-1; ++k) {
                         int new_coef=0;
                           new_coef=s_c*s_kj[k][newIndex];

                          W_vars[k+1][newIndex+1] = model.addVar(0, 1, new_coef, GRB_CONTINUOUS, "y_" + std::to_string(k+1) + "_" + std::to_string(newIndex+1));
                             W_vars[newIndex+1][k+1] = model.addVar(0, 1, new_coef, GRB_CONTINUOUS, "y_" + std::to_string(newIndex+1) + "_" + std::to_string(k+1));

                    } 

                         int new_coef=0;
                                new_coef=s_c*pattern_i_count;


                          W_vars[depot_idx][newIndex+1] = model.addVar(0, 1, new_coef, GRB_CONTINUOUS, "y_" + std::to_string(depot_idx) + "_" + std::to_string(newIndex+1));
                             W_vars[newIndex+1][depot_idx] = model.addVar(0, 1, new_coef, GRB_CONTINUOUS, "y_" + std::to_string(newIndex+1) + "_" + std::to_string(depot_idx));

                    

                    W_vars[newIndex+1][newIndex+1] = model.addVar(0, 0, 0, GRB_CONTINUOUS, "y_" + std::to_string(newIndex+1) + "_" + std::to_string(newIndex+1));
                       
           //atualiza upper bound das mtz
             for (int j = 0; j <= N; j++) {
                V_vars[j].set(GRB_DoubleAttr_UB, N);
            } 
            
  // 3. Redimensione o vetor que armazena as restrições
MTZ.resize(N);
for (int j = 0; j < N; j++) {
    MTZ[j].resize(N); // Redimensiona cada linha
}


// BLOCO DE DEPURAÇÃO: CHECAGEM DE TAMANHOS ANTES DO LAÇO MTZ
// ========================================================================
//cout << "--- CHECAGEM ANTES DO LACO MTZ ---" << endl;
//cout << "Valor de N = " << N << endl;
//cout << "Tamanho de MTZ (linhas): " << MTZ.size() << endl;
//if (!MTZ.empty()) {
  //  cout << "Tamanho de MTZ[0] (colunas): " << MTZ[0].size() << endl;
//}
//cout << "Tamanho de V_vars: " << V_vars.size() << endl;
//cout << "Tamanho de W_vars (linhas): " << W_vars.size() << endl;
//if (!W_vars.empty()) {
 //   cout << "Tamanho de W_vars[0] (colunas): " << W_vars[0].size() << endl;
  //  cout << "Tamanho de W_vars.back() (ultima linha): " << W_vars.back().size() << endl;
//}
//cout << "------------------------------------" << endl;

// 4. Adicione o conjunto completo de novas restrições MTZ
//cout << "Adicionando " << N * (N - 1) << " novas restrições MTZ..." << endl;



for (int j = 0; j < N; j++) {
    for (int l = 0; l < N; l++) {
        if (j != l) {
            // Adiciona a nova restrição com os novos V_vars, W_vars e o novo BIG_M
            // Nota: Os vetores V_vars e W_vars também precisam ter sido redimensionados
            // e a nova variável (índice N+1) adicionada a eles.
            MTZ[j][l] = model.addConstr(V_vars[l+1] >= V_vars[j+1] + 1 - BIG_M_MTZ * (1 - W_vars[j+1][l+1]), 
                                       "MTZ_" + to_string(j) + "_" + to_string(l));
        }
    }
}          

 
  model.update();
      


       // Update the demand constraints with the new pattern
        for (int i = 0; i < P; ++i) {
           model.chgCoeff(demandConstraints[i], newVar, newPattern[i]);
        }

             cout << " errrr 000 " << endl;
        // atualiza a restrição de capacidade com novo xj
        model.chgCoeff(Capacity,newVar,time_obj);

     

        for (int jj = 0; jj < patterns.size()-1; ++jj) {
          // if (jj != newIndex && s_kj[newIndex][jj] != 0)
            model.chgCoeff(Capacity, W_vars[newIndex+1][jj+1], time_item * s_kj[newIndex][jj]);

            //if (s_kj[jj][newIndex] != 0)
             model.chgCoeff(Capacity, W_vars[jj+1][newIndex+1], time_item * s_kj[jj][newIndex]);
          
        }
        
              model.chgCoeff(Capacity, W_vars[newIndex+1][depot_idx], time_item * pattern_i_count);

            //if (s_kj[jj][newIndex] != 0)
             model.chgCoeff(Capacity, W_vars[depot_idx][newIndex+1], time_item * pattern_i_count);      


             

// Itera sobre todas as restrições de grau existentes (para os nós antigos)
for (int j = 0; j < newIndex; ++j) {
    // Adiciona a nova variável W_vars[newIndex][j] (arco entrando em j)
    // à restrição de grau de entrada de j (Indegree[j]).
    // O coeficiente é 1.0.
    model.chgCoeff(Flow_in[j], W_vars[newIndex+1][j+1], 1.0);

    // Adiciona a nova variável W_vars[j][newIndex] (arco saindo de j)
    // à restrição de grau de saída de j (Outdegree[j]).
    // O coeficiente é 1.0.
    model.chgCoeff(Flow_out[j], W_vars[j+1][newIndex+1], 1.0);
}


// O lado esquerdo (LHS) dessas novas restrições irá percorrer todas as
// variáveis existentes e a nova.
GRBLinExpr newInflow = 0;
GRBLinExpr newOutflow = 0;
for (int i = 0; i < newIndex; ++i) {
    newInflow += W_vars[i+1][newIndex+1];
    newOutflow += W_vars[newIndex+1][i+1];
}
 
Flow_in.push_back(model.addConstr(newInflow == newYVar, "Indegree_" + std::to_string(newIndex)));
Flow_out.push_back(model.addConstr(newOutflow == newYVar, "Outdegree_" + std::to_string(newIndex)));


            // d) Fluxo para o Depósito (j=0)
            
            GRBLinExpr start_tour1 = 0;
            model.remove(Flow_start);
            for (int j = 0; j < patterns.size(); j++) {
                //if(j!=depot_idx)
                   start_tour1 += W_vars[depot_idx][j+1];
            }
           Flow_start= model.addConstr(start_tour1 <= 1, "Start_Tour");

        
             model.remove(Flow_end);
            GRBLinExpr end_tour1 = 0;
            for (int j = 0; j < patterns.size(); j++) {
                //if(j!=depot_idx)
                  end_tour1 += W_vars[j+1][depot_idx];
            }
            Flow_end=model.addConstr(start_tour1 == end_tour1, "Connect_Tour");

      
    
          model.update();

   }    

 
 
    if (ZRMPit1 - ZRMPit2 < 0.0001) it_RMP = it_RMP + 1; // se não melhorou o master iteração recebe +1

    if(Check_CG==0)
      break; // optimal solution found

      if (it_RMP >= 5) {
        std::cout << "Terminating column generation with tailling off.\n";
        break; // tailing off
      }
      ZRMPit1=ZRMPit2;
  // Adiciona todas as variáveis, restrições e objetivo ao modelo mestre
         model.write("master_model.lp");  // Salva o modelo mestre em um arquivo



      model.optimize();

      // Verifica se a solução é ótima antes de acessar ObjVal
//if (masterModel.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
  double objValue1 = model.get(GRB_DoubleAttr_ObjVal);
  std::cout << "Objective Value of the Master Model: " << objValue1 << std::endl;
  ZRMPit2=objValue1;
  LP_value= objValue1;  
  lowerBound=objValue1;


  //  std::cout << "Variable Values:" << std::endl;
//  for (size_t i = 0; i < vars.size(); ++i) {
   //   std::cout << "x" << i << " = " << vars[i].get(GRB_DoubleAttr_X) << std::endl;
//  }
//} else {
//  std::cout << "No optimal solution found. Status: " << masterModel.get(GRB_IntAttr_Status) << std::endl;
//}


  }  // end while*/

        auto end = std::chrono::high_resolution_clock::now();

    // Calcula a diferença (duração)
    std::chrono::duration<double> elapsed = end - start;

  /*model.remove(Capacity);

           capacityExpr = 0;
            for (int j = 0; j < N; ++j) {
                capacityExpr += time_obj * Z_vars[j];
                for (int l = 0; l < N; ++l) {
                     if (j != l) {
                        capacityExpr += W_vars[j+1][l+1] * time_item * s_kj[j][l];
                     }
                }
            }
            Capacity = model.addConstr(capacityExpr <= 2*O, "capacity_" + to_string(0));

            model.update();*/
   

            // ========================================================================
            // FASE 2: CONVERSÃO DE VARIÁVEIS E OTIMIZAÇÃO DO MIP
            // ========================================================================
            cout << "\n--- FASE 2: Convertendo variáveis e resolvendo o MIP ---" << endl;
            /*
            for (int j = 0; j < N; j++) {
                Z_vars[j].set(GRB_CharAttr_VType, GRB_INTEGER);
                U_vars[j].set(GRB_CharAttr_VType, GRB_BINARY);
            }
            for (int j = 0; j <= N; j++) {
                for (int l = 0; l <= N; l++) {
                    if (j != l) W_vars[j][l].set(GRB_CharAttr_VType, GRB_BINARY);
                }
            }
            */
            model.set(GRB_DoubleParam_TimeLimit, MAXTIME);
           // model.set(GRB_DoubleParam_MemLimit, 9.0);
            model.set(GRB_IntParam_Threads, 1);

          //  model.set(GRB_DoubleParam_MIPGap, 0.001);
            model.optimize();

            // COLETA E ESCRITA DOS RESULTADOS FINAIS
            int status = model.get(GRB_IntAttr_Status);
           // double timeSpent = model.get(GRB_DoubleAttr_Runtime);
           double timeSpent = model.get(GRB_DoubleAttr_Runtime) + elapsed.count();
             int total_rolls = 0; int patterns_used = 0, setup_count=0;
              double objValue =0; double finalGap=0;

            if (status == GRB_OPTIMAL || status == GRB_SUBOPTIMAL || (status == GRB_TIME_LIMIT && model.get(GRB_IntAttr_SolCount) > 0)) {
                 objValue = model.get(GRB_DoubleAttr_ObjVal);
                  objValue=number_CG;
              //  finalGap = model.get(GRB_DoubleAttr_MIPGap);
                finalGap = 100*finalGap;
               

        for (int j = 0; j < patterns.size(); ++j) {
       //   std::cout << "x[" << t << "][" << j << "] = " << vars[t][j].get(GRB_DoubleAttr_X)
         //           << " e y[" << t << "][" << j << "] = " << Yvars[t][j].get(GRB_DoubleAttr_X) << std::endl;
         if(Z_vars[j].get(GRB_DoubleAttr_X)>0){
            patterns_used++;
            XJ+=Z_vars[j].get(GRB_DoubleAttr_X);
             std::cout<< " pattern index "<< j<<  " frequency: "<< Z_vars[j].get(GRB_DoubleAttr_X)<<std::endl;
            for(int i=0;i<P;i++)
               std::cout<< patterns[j][i] << " ";
        
            std::cout<<std::endl;

         }
                   if(W_vars[depot_idx][j+1].get(GRB_DoubleAttr_X)>0 && (j+1)!=depot_idx )
                    {
                                                int ail=0;
                                                for(int i=0; i<P;i++){
                                                      ail+=patterns[j][i];
                                                }
                                        setup_count+=ail;
                    }
                                       if(W_vars[j+1][depot_idx].get(GRB_DoubleAttr_X)>0 && (j+1)!=depot_idx )
                    {
                                                int ail=0;
                                                for(int i=0; i<P;i++){
                                                      ail+=patterns[j][i];
                                                }
                                        setup_count+=ail;
                    }    
            for (int jj = 0; jj< patterns.size(); ++jj) {
                if(j!=jj)
                {
                  if(W_vars[j+1][jj+1].get(GRB_DoubleAttr_X)>0 && (j+1)!=depot_idx && (jj+1)!=depot_idx){
                       setup_count+=s_kj[j][jj];
                        cout<< " houve troca "<< j << " para "<< jj<< " valor "<< s_kj[j][jj] << endl;
                    }               
            }
      }
    }
       double estoque=0;         
                WriteResults(lowerBound, objValue, timeSpent, finalGap, nameTable,  XJ, patterns_used, setup_count);
            } else {
                cout << "Nenhuma solução viável para o MIP encontrada. Status: " << status << endl;
            }

        } catch (GRBException& e) {
            cerr << "Erro no Gurobi, código = " << e.getErrorCode() << endl;
            cerr << e.getMessage() << endl;
        } catch (...) {
            cerr << "Uma exceção ocorreu." << endl;
        }

//clear variables
Wp.clear();
D_p.clear();
CTt.clear();
Stock_costs.clear();

    }

    fclose(arqProblems);
    return 0;
}
